precio_producto = float(input("Ingresa el precio del producto: "))
iva = precio_producto * 0.19
print("El valor del IVA es:", iva)