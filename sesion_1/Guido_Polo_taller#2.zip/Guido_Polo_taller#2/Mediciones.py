pulgadas = float(input("Ingresa una medida en pulgadas: "))
milimetros = pulgadas * 25.4
print(pulgadas, "pulgadas equivale a", milimetros, "milímetros.")
