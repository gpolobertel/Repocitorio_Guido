fahrenheit = float(input("Ingresa una temperatura en grados Fahrenheit: "))
celsius = (fahrenheit - 32) * 5 / 9
print("Equivalente en grados Celsius:", celsius)
